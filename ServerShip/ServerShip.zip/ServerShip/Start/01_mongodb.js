/**
 * Created by Andrzej on 2016-05-01.
 */
var mongoose = require('mongoose');

module.exports = gamedb = mongoose.createConnection(config.database);