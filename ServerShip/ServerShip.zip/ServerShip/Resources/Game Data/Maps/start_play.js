/**
 * Created by Andrzej on 2016-05-01.
 */

exports.name = "Home Town";

//game maker room
exports.room = "ad_game";

exports.start_x = 320;
exports.start_y = 320;

exports.clients = [];